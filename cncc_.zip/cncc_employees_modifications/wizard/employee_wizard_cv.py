# models/hr_applicant.py
from odoo import models, fields, api
from werkzeug.urls import url_encode

class EmployeeCVInherit(models.TransientModel): 
    _inherit = 'hr.employee.cv.wizard'

    employee_ids = fields.Many2many('hr.employee')

    show_private_street = fields.Boolean(string='Private Street', default=True)
    can_show_private_street = fields.Boolean(compute='_compute_can_show_other')

    @api.depends('employee_ids')
    def _compute_can_show_others(self):
        res = super(EmployeeCVInherit, self)._compute_can_show_others()
        for wizard in self:
            wizard.can_show_private_street = wizard.employee_ids.private_street
        return res
    
    def action_validate(self):
        res1 = super(EmployeeCVInherit, self).action_validate()
        self.ensure_one()
        url_params = {
            'employee_ids': ','.join(str(x) for x in self.employee_ids.ids),
            'color_primary': self.color_primary,
            'color_secondary': self.color_secondary,
            'show_skills': 1 if self.show_skills else None,
            'show_contact': 1 if self.show_contact else None,
            'show_others': 1 if self.show_others else None,
            'show_private_street': 1 if self.show_private_street else None,
        }
        url = '/print/cv?' + url_encode(url_params)
        return res1