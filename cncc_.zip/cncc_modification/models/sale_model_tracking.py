# models/hr_applicant.py
from odoo import models, fields

class HrApplicantInherit(models.Model): 
    _inherit = 'hr.applicant'