from . import hr_job_model
from . import hr_job_skill
from . import hr_job_position
