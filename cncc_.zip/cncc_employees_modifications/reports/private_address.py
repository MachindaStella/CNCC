from collections import defaultdict

from odoo import _, models 

class PrivateStreetReport(models.AbstractModel):
    _name = 'report.cncc_employees_modifications.report_private_street'
    _description = 'Employee Private Street'

    def _get_report_values(self, docids, data=None):
        show_private_street = (data or {}).get('show_private_street')
        employees = self.env['hr.employee'].browse(docids)

        resume_lines = {}
        for employee in employees:
            resume_lines[employee] = defaultdict(self.env['hr.resume.line'].browse)
            for line in employee.resume_line_ids:
                if not show_private_street and not line.line_type_id:
                    continue
                resume_lines[employee][line.line_type_id.name or _('Private')] |= line

        return {
            'doc_ids': docids,
            'doc_model': 'hr.employee',
            'docs': employees,
            'resume_lines': resume_lines,
        }