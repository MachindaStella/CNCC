from odoo import models, fields,api

class SurveyUpdate(models.Model):
    _inherit = 'survey.survey'
    _description = 'Update Survey'
    
    employee_id = fields.Many2one('hr.employee', string='Employee', store=True)
    candidate_id = fields.Many2one('hr.applicant', string='Candidate', store=True)
    
