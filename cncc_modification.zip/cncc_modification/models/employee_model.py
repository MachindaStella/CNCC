from odoo import models, fields, api
import random
import string

class EmployeeCopy(models.Model):
    _inherit = 'hr.employee'
    _description = 'Employee Modifications'

    matricule = fields.Char(string="Matricule",readonly=True)
    
    _sql_constraints = [
        ('matricule_uniq', 'unique (matricule)', "The Matricule must be unique, this one is already assigned to another employee."),
        ('user_uniq', 'unique (user_id, company_id)', "A user cannot be linked to multiple employees in the same company.")
    ]
    
    
    def generate_random_matricule(self):
        for employee in self:
            employee.matricule = 'cncc' + ''.join(random.choice(string.digits) for i in range(9))

            
            

    # @api.model
    # def create(self, vals):
    #     if 'name' in vals:
    #         employee_name = vals['name']
    #         matricule = self._generate_matricule(employee_name)
    #         vals['matricule'] = matricule
    #     return super(EmployeeCopy, self).create(vals)

    # def _generate_matricule(self, employee_name):
    #     initials = employee_name[:2].upper()

    #     sequence = self.env['ir.sequence'].next_by_code('employee.matricule.sequence')
    #     if not sequence:
    #         sequence = 0

    #     matricule = f"{initials}{sequence:02d}"

    #     # Update the sequence value for the next employee
    #     self.env['ir.sequence'].sudo().write({
    #         'number_next_actual': sequence + 1,
    #     })

    #     return matricule
