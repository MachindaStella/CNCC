from odoo import models, fields, api

class JobCopy(models.Model):
    _inherit = 'hr.skill'
    _rec_name = 'name'
