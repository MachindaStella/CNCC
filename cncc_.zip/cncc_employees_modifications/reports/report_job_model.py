from odoo import models, fields, api
import time

class ReportHRJob(models.AbstractModel):
    _name = 'cncc_employees_modifications.report_hr_job_document'
    _description = 'HR Job Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['hr.job'].browse(docids)
        return {
            'docs': docs,
            'current_date': time.strftime('%Y-%m-%d'),
        }
    
    def render_qweb_pdf(self, report_ref, docids, data=None):
        res = super(ReportHRJob, self).render_qweb_pdf(report_ref, docids, data=data)
        res[0] = self.env['ir.actions.report']._set_page_numbers(res[0])
        return res