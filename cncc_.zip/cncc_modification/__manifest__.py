# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'Employee Modification',
    'category': 'hr',
    'summary': 'Centralize your address book',
    'description': """
Adding matricule to each employee
""",
    'depends': ['base', "hr", "hr_recruitment", "survey"],
    'data': [
        'views/employee_matricule_view.xml',
        # 'views/trial_period_commitment_view.xml',
        'views/appliance_inheritance_view.xml',
        'views/survey_update_view.xml',
        'views/survey_result_view.xml',
        'reports/ir_actions_report.xml',
        'reports/trail_report_template.xml',
        'wizard/evaluation_wizard_view.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'license': 'LGPL-3',
   
}
