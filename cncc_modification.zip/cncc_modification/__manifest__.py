# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'Employee Modification',
    'category': 'hr',
    'summary': 'Centralize your address book',
    'description': """
Adding matricule to each employee
""",
    'depends': ['base', "hr"],
    'data': [
        'views/employee_matricule_view.xml',
    'application': True,
    'license': 'LGPL-3',
   
}
