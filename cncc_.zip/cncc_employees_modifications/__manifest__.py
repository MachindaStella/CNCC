# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'Employee Modification',
    'category': 'hr',
    'summary': 'Centralize your address book',
    'description': """
Adding matricule to each employee
""",
    'depends': ['base', "hr", "hr_skills","report_qweb_element_page_visibility"],
    'data': [
        # 'wizard/employee_cv_view.xml',
        # 'reports/private_street_view.xml',
        # 'reports/employee_private_street_view.xml',
        # 'views/employee_private_street_template_view.xml',
        'views/hr_job_position_view.xml',
        'views/hr_employee_competence_view.xml',
        'reports/report_job.xml',
        'reports/hr_job_action.xml',
        # 'views/hr_job_recruitment_view.xml',
        
    ],
    'application': True,
    'license': 'LGPL-3',
   
}