from odoo import models, fields,api

class SurveyResult(models.Model):
    _inherit = 'survey.user_input'
    _description = 'Result Survey'


    
    candidate_id = fields.Many2one('hr.applicant' ,string='Candidate', store=True)
    candidate_name = fields.Char(string='Candidate')


    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if 'candidate_id' in vals and 'candidate_name' not in vals:
                applicant = self.env['hr.applicant'].browse(vals['candidate_id'])
                if applicant:
                    vals['candidate_name'] = applicant.partner_name
                    
        return super(SurveyResult, self).create(vals_list)