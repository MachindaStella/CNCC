from odoo import models, fields, api
from odoo.exceptions import UserError
import uuid
import logging

_logger = logging.getLogger(__name__)

class SurveyWizard(models.TransientModel):
    _name = 'recruitment.survey.wizard'
    _description = 'Recruitment Survey Wizard'

    survey_id = fields.Many2one('survey.survey', string="Choisir l'évaluation")
    candidate_id = fields.Many2one('hr.applicant', string="Candidate")
    access_token = fields.Char('Access Token', default=lambda self: str(uuid.uuid4()), copy=False)
    
    def action_open_survey(self):
        self.ensure_one()
        print("**************************************", self.candidate_id)

        # Fetch the partner name from the candidate (hr.applicant)
        candidate = self.candidate_id
        if not candidate.partner_name:
            raise UserError("Le candidat sélectionné n'a pas de nom.")

        # Create a survey.user_input record
        user_input = self.env['survey.user_input'].create({
            'survey_id': self.survey_id.id,
            'partner_id': candidate.partner_id.id,
            'email': candidate.email_from,
            'candidate_id': candidate.id,
            'candidate_name': candidate.partner_name,
            'test_entry': True,  # Assuming it's a test entry
        })

        # Explicitly commit the transaction to ensure data is written
        self.env.cr.commit()
        _logger.info("Data successfully written and committed for survey ID %s", self.survey_id.id)

        # Construct URL or action to open the survey form
        return {
            'type': 'ir.actions.act_url',
            'url': '/survey/test/%s' % self.survey_id.access_token,
            'target': 'new',  # Open in a new window/tab
        }

    def action_share_survey(self):
        self.ensure_one()
        self.survey_id.check_validity()

        template = self.env.ref('survey.mail_template_user_input_invite', raise_if_not_found=False)
        local_context = dict(
            self.env.context,
            default_survey_id=self.survey_id.id,
            default_template_id=template and template.id or False,
            default_email_layout_xmlid='mail.mail_notification_light',
            default_send_email=(self.survey_id.access_mode != 'public'),
        )
        return {
            'type': 'ir.actions.act_window',
            'name': "Share a Survey",
            'view_mode': 'form',
            'res_model': 'survey.invite',
            'target': 'new',
            'context': local_context,
        }