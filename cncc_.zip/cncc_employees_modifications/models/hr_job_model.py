from odoo import models, fields, api
import random
import string
import time

job_status= [
    ('cadre_superieur', "Cadre Supérieur"),
    ('cadre', "Cadre"),
    ('agent_de_maitrise', "Agent De Maîtrise"),
    ('agent_dexecution ', "Agent D'exécution"),
]
class JobCopy(models.Model):
    _inherit = 'hr.job'

    
    status = fields.Selection(
        selection=job_status,
        string="Statut",
    
        tracking=True,
        default='cadre_superieur')
    a_pour_sup_hierar = fields.Many2one('hr.job',string="A pour supérieur hiérarchique")
    est_le_sup_hierar_de = fields.Many2one('hr.job',string="Est le supérieur hiérarchique de")
    personnel_rem = fields.Many2one('hr.job',string="En cas d'absence, peut-être remplacé par")
    condition_fonction = fields.Char(string="Conditions d'exercice de la fonction")
    relation_externe = fields.Char(string="Relation Externes")
    la_hierarchie = fields.Char(string="La hiérarchie")
    autres = fields.Char(string="Les Autres Structures")
    code = fields.Char(string="Code")


    job_skill_ids = fields.One2many('hr.job.skill', 'job_id', string="Skills")
    skill_ids = fields.Many2many('hr.skill', compute='_compute_skill_ids', store=True)



    @api.depends('job_skill_ids.skill_id')
    def _compute_skill_ids(self):
        for job in self:
            job.skill_ids = job.job_skill_ids.mapped('skill_id')

