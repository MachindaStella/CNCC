from odoo import fields, models

class TrialPeriodCommitment(models.Model):
    _name = 'trial.period.commitment'
    _description = 'Trail Period Commitment Document'

    company_name = fields.Many2one('res.company', string='Company Name', required=True)
    amount = fields.Integer(string='Amount', required=True)
    immatriculation_num = fields.Integer(string='Immatriculation Number', required=True)
    director_name = fields.Char(string='Director Name and Surname Name', required=True)
    worker_name = fields.Many2one('res.users', string='Work Name', required=True)
    worker_dob = fields.Date(string='Worker Date', required=True)
    worker_nationality = fields.Char(string='Worker Nationality', required=True)
    worker_address = fields.Char(string='Worker Address', required=True)
    
