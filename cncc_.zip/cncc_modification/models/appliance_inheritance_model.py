# models/hr_applicant.py
from odoo import models, fields, api
from odoo.exceptions import UserError

class HrApplicantInherit(models.Model): 
    _inherit = 'hr.applicant'
    _rec_name = 'partner_name'


    survey_id = fields.Many2one('survey.survey', string='Survey')

   
    def open_wizard(self):
        candidates = self.env['hr.applicant']
        active_id = self.env.context.get('active_id')

        if active_id:
            candidate = candidates.browse(active_id)
            candidate_id = candidate.id
            candidate_name = candidate.partner_name
        return {
            'name': 'Évaluation',
            'type': 'ir.actions.act_window',
            'res_model': 'recruitment.survey.wizard',
            'view_mode': 'form',
            'view_ref': 'cncc_modification.view_recruitment_survey_wizard_form',
            'target': 'new',
            'context': {
                'default_candidate_id': self.id,
                'active_id': self.env.context.get('active_id'),
                'survey_id' : self.survey_id.id
            },
        
        } 
        
  
    def action_survey_user_input(self):
       return {
        'type': 'ir.actions.act_window',
        'name': 'Survey Inputs',
        'res_model': 'survey.user_input',
        'view_mode': 'tree,form',
        'domain': [('candidate_name', '=', self.partner_name)],
        'context': {'default_candidate_id': self.id,
            'default_candidate_name': self.partner_name},
    }


    # def action_survey_user_input(self):
    #     return {
    #         'type': 'ir.actions.act_window',
    #         'name': 'Survey Inputs',
    #         'res_model': 'survey.user_input',
    #         'view_mode': 'tree,form',
    #         'domain': [('candidate_id', '=', self.id)],
    #         'context': {
    #             'default_candidate_id': self.id,
    #             'active_id': self.id,
    #         },
    #         'target': 'current',
    #     }
    